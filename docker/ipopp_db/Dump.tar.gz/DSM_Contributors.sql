-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: DSM
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Contributors`
--

DROP TABLE IF EXISTS `Contributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contributors` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`),
  KEY `path_2` (`path`)
) ENGINE=InnoDB AUTO_INCREMENT=38376 DEFAULT CHARSET=latin1 COMMENT='A list of files and URLs that were used to create a product.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contributors`
--

LOCK TABLES `Contributors` WRITE;
/*!40000 ALTER TABLE `Contributors` DISABLE KEYS */;
INSERT INTO `Contributors` VALUES (33550,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016101401.dat',' '),(33551,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016101402.dat',' '),(33554,'/thing1/ipopp-nrt/pub/ancillary/LUTs/aqua/modis/MYD02_Reflective_LUTs.V6.1.17.8.hdf',' '),(33555,'/thing1/ipopp-nrt/pub/ancillary/LUTs/aqua/modis/MYD02_Emissive_LUTs.V6.1.17.8.hdf',' '),(33556,'/thing1/ipopp-nrt/pub/ancillary/LUTs/aqua/modis/MYD02_QA_LUTs.V6.1.17.8.hdf',' '),(33563,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016101701.dat',' '),(33564,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016101702.dat',' '),(33567,'/thing1/ipopp-nrt/pub/ancillary/LUTs/terra/modis/MOD02_Reflective_LUTs.V6.1.14.22.hdf',' '),(33568,'/thing1/ipopp-nrt/pub/ancillary/LUTs/terra/modis/MOD02_Emissive_LUTs.V6.1.14.22.hdf',' '),(33569,'/thing1/ipopp-nrt/pub/ancillary/LUTs/terra/modis/MOD02_QA_LUTs.V6.1.14.22.hdf',' '),(35181,'/home/ipopp/temp/MYD02_Reflective_LUTs.V6.1.17.8.hdf',' '),(35182,'/home/ipopp/temp/MYD02_Emissive_LUTs.V6.1.17.8.hdf',' '),(35183,'/home/ipopp/temp/MYD02_QA_LUTs.V6.1.17.8.hdf',' '),(35220,'/home/ipopp/temp/leapsec.2016101701.dat',' '),(35221,'/home/ipopp/temp/utcpole.2016101702.dat',' '),(35311,'/home/ipopp/temp/MOD02_Reflective_LUTs.V6.1.14.22.hdf',' '),(35312,'/home/ipopp/temp/MOD02_Emissive_LUTs.V6.1.14.22.hdf',' '),(35313,'/home/ipopp/temp/MOD02_QA_LUTs.V6.1.14.22.hdf',' '),(35437,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016101901.dat',' '),(35438,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016101902.dat',' '),(35462,'/home/ipopp/temp/leapsec.2016101901.dat',' '),(35463,'/home/ipopp/temp/utcpole.2016101902.dat',' '),(36081,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016102101.dat',' '),(36095,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016102102.dat',' '),(36210,'/home/ipopp/temp/leapsec.2016102101.dat',' '),(36211,'/home/ipopp/temp/utcpole.2016102102.dat',' '),(37107,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016102401.dat',' '),(37108,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016102402.dat',' '),(37160,'/home/ipopp/temp/leapsec.2016102401.dat',' '),(37161,'/home/ipopp/temp/utcpole.2016102402.dat',' '),(37845,'/home/ipopp/temp/leapsec.2016102601.dat',' '),(37846,'/home/ipopp/temp/utcpole.2016102602.dat',' '),(37852,'/thing1/ipopp-nrt/pub/ancillary/temporal/leapsec.2016102601.dat',' '),(37853,'/thing1/ipopp-nrt/pub/ancillary/temporal/utcpole.2016102602.dat',' ');
/*!40000 ALTER TABLE `Contributors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-27 13:39:55
